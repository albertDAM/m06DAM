package enric;

public class Equip {
    private int num;


}
