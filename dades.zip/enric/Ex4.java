package enric;

import java.io.IOException;

public class Ex4 {

    public static void main(String[] args) throws IOException {

        Crear cff1 = new Crear(2        ); //2 teams 2 partidos
//        Crear cff2 = new Crear(3        );
//        Crear cff3 = new Crear(4        );
//        Crear cff4 = new Crear(10        );






    }
}
