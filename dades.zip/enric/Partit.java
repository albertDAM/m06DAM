package enric;

import java.io.Serializable;
import java.util.Date;

public class Partit implements Serializable{
//la opción 2 del menú llamará a este método
    short gol1, gol2;
    String arb;
    Date date;


    private static final long serialVersionUID = 1;
//los partidos(enfrentamiento entre 2 equipos) están en el archivo en el byte tal??
    //1. crearlo vacío



    public Partit(int gol1, int gol2, String arb, Date date) {


    //TODO comprobar si no está introducido


    }




}
